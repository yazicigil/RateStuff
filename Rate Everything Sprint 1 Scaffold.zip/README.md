# RateEverything — Sprint 1 Scaffold

Minimal Next.js (App Router) + Tailwind + Prisma (Postgres).

## Kurulum

```bash
pnpm i   # veya npm i / yarn
cp .env.example .env
# .env içindeki DATABASE_URL'i Postgres bağlantınla değiştir
npx prisma db push
npm run dev
```

## Yol Haritası (Sprint 2)

- /app/api/items + server actions
- Signed URL ile R2/S3 upload
- NextAuth (Google + email magic link)
- Arama (ILIKE → FTS) ve Trend (Wilson lower bound)
- SWR/React Query ve URL senkronizasyonu
