'use client';
import { useState } from "react";
export default function StarRating({ value = 0, onChange }: { value?: number, onChange?: (v:number)=>void }) {
  const [hover, setHover] = useState<number | null>(null);
  return (
    <div className="flex gap-1">
      {[1,2,3,4,5].map(i => (
        <button key={i} type="button"
          className={"px-2 py-1 rounded " + ((hover ?? value) >= i ? "bg-white/20" : "bg-white/5")}
          onMouseEnter={()=>setHover(i)} onMouseLeave={()=>setHover(null)} onClick={()=>onChange?.(i)} aria-label={`${i} yıldız`}>★</button>
      ))}
    </div>
  );
}
