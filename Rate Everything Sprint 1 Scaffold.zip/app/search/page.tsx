export default function SearchPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">Arama</h1>
      <div className="card">Arama alanı ve sonuçlar.</div>
    </div>
  );
}
