import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "RateEverything",
  description: "Add anything. Rate everything.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="tr">
      <body>
        <header className="border-b border-white/10">
          <div className="container flex items-center gap-4 py-4">
            <div className="text-xl font-semibold">RateEverything</div>
            <nav className="ml-auto flex gap-2">
              <a className="btn" href="/">Anasayfa</a>
              <a className="btn" href="/profile">Profil</a>
            </nav>
          </div>
        </header>
        <main className="container py-6">{children}</main>
      </body>
    </html>
  );
}
