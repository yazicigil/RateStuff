export default function ProfilePage() {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">Profil</h1>
      <div className="card">Auth gelince dolar.</div>
    </div>
  );
}
