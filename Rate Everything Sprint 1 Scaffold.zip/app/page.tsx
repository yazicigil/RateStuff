import Link from "next/link";

export default function HomePage() {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">Trendler & Arama</h1>
      <div className="card">
        <p>Bu, backend'e bağlanacak iskelet.</p>
        <div className="mt-4 flex gap-2">
          <Link className="btn" href="/items/new">Yeni Item Ekle</Link>
          <Link className="btn" href="/search">Ara</Link>
        </div>
      </div>
    </div>
  );
}
